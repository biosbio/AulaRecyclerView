package com.example.recicleview

data class Fruit(
    val name: String,
)
