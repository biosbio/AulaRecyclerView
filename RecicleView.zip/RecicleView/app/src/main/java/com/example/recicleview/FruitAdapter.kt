package com.example.recicleview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

//class FruitAdapter (private val fruits: List<String>,  private val fruitsquant: List<String>):RecyclerView.Adapter<FruitAdapter.FruitViewHolder>() {
class FruitAdapter (private val fruits: List<String>):RecyclerView.Adapter<FruitAdapter.FruitViewHolder>() {
    class FruitViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fruitName: TextView = itemView.findViewById(R.id.fruit_name)
      // val fruitquant: TextView = itemView.findViewById(R.id.fruit_quant)
    }

    override fun onCreateViewHolder(parent: ViewGroup,viewType: Int): FruitAdapter.FruitViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.fruit_item, parent, false)
        return FruitViewHolder(view)

    }

    override fun onBindViewHolder(holder: FruitAdapter.FruitViewHolder, position: Int) {
        holder.fruitName.text = fruits[position]
       //holder.fruitquant.text = fruits[position]
    }


    override fun getItemCount(): Int {
        return fruits.size

    }
}